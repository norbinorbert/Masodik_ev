%parameternek kell megadni, hogy hany pontot akarunk beolvasni
function feladat2(n) %II.3
xx = zeros(1,n);
fx = zeros(1,n);
figure

%pontok beolvasasa
for i=1:n
    [xx(i),fx(i)] = ginput(1);
end

%pontok kirajzolasa
plot(xx, fx, 'r*');
hold on

%minden pontpar kozott kiszamolom a nullarendu Spline 
%fuggvenyt es abrazolom
for i=1:n-1
    kisebb = min(xx(i), xx(i+1));
    nagyobb = max(xx(i), xx(i+1));
    X = kisebb:0.001:nagyobb;
    
    %ket ponton atmeno egyenes egyenlete
    m = (fx(i)-fx(i+1)) / (xx(i)-xx(i+1));
    f = @(x) m*(x-xx(i)) + fx(i);
    
    XX = linspace(kisebb, nagyobb, 100);
    FX = f(XX);
    
    new_fx = zeros(1, length(X));
    %spline fuggveny erteke minden kozbeeso pont eseten
    for k = 1 : length(X)
        new_fx(k) = splineFunction(XX, FX, X(k));
    end
    plot(X, new_fx, 'b');
end

end