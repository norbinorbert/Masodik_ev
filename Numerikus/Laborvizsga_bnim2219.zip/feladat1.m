function megoldas = feladat1 %I.7
%"sqrt(40) = x" egyenlet gyoket szeretnenk meghatarozni
%mivel sqrt(40)-et nem ismerjuk, ezert negyzetre emelunk
%40 = x^2 gyokeit meg tudjuk kapni a szelomodszerrel
f = @(x) x.^2-40;

%3 tizedesnyi pontossag
pontossag = 10^(-4);

%olyan intervallumot veszunk, amelybe benne van a megoldas
%6=sqrt(36) < sqrt(40) < sqrt(49)=7
intervallum = [6,7];

megoldas = Szelomodszer(f, intervallum(1), intervallum(2), pontossag, 10);

end