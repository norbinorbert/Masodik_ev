package Lab8;

//Boda Norbert, 521
public interface Plant {
    public double getOxygenAmountPerYear();
    public int getLifeTime();
    public String getRepresentation();
}
