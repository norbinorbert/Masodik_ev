public class L01_bnim2219_1 {
    public static void main(String[] args) {
        System.out.println("Hello Norbi!");
    }
}