//Boda Norbert, 521
public interface MainDish {
    @Override
    public String toString();
}
