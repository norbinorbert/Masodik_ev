//Boda Norbert, 521
public interface Soup {
    public void associateMainDish(MainDish d);
    @Override
    public String toString();
}
