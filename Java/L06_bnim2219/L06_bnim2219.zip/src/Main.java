import java.util.Date;

//Boda Norbert, 521
public class Main {
    public static void main(String[] args) {
        new DateFrame();
        new MoveCircleFrame();
        new PushFrame();
    }
}