import java.awt.*;

//Boda Norbert, 521
public interface Pizza {
    public void bake(Graphics g);
    public int getPrice();
    public String getIngredients();
}
