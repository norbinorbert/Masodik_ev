//Boda Norbert, 521
public class Main {
    public static void main(String[] args) {
        new ColorFrame();
        new TextFilterFrame();
        new GroceryListFrame();
    }
}