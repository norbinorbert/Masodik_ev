//Boda Norbert, Lab4_10, bnim2219

/*10. A bevezető figyelmes átolvasása után oldjuk meg a következő feladatot:
Egy menzán 4 asztal van, mindegyik 2 férőhelyes. Az érkező kliensek (15 törzsvendég, akiket egy-egy szál szimulál)
rendre leülnek az asztalokhoz, amennyiben van üres hely (írjuk ki, hogy ki melyik asztalnál foglalt helyet). Ha van
teljesen üres asztal, akkor oda ül a vendég, ha nem, akkor egy üres helyre. Miután befejezték az evést, felszabadítják
a helyet, és jöhet egy másik kliens. Egy bizonyos idő után bármelyik ember megéhezik, tehát visszatér az étterembe.
10 "óra" eltelte után az étterem bezárul, és a kliensek hazamennek.
Egy kliens írjon ki üzenetet, amikor:
(ismét) belép a menzára
helyet talál (vagy nem talál, ezért elmegy egy időre) - hova ült le
feláll, így felszabadul a helye (legyen követhető, hogy melyek a szabad/foglalt helyek)
hazamegy
A főszál írjon ki üzenetet, amikor:
megnyílt a menza
eltelt a 10 óra, ezért az étterem bezárul
Megj.: feltételes változók és mutexek segítségével biztosítsuk, hogy a kiírások sorrendje helyes legyen.*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>

#define VENDEGEK_SZAMA 15
#define ASZTALOK_SZAMA 4
#define FEROHELY 2

short asztalok[ASZTALOK_SZAMA];
bool bezart = false;

//kiirasra hasznalt mutex
pthread_mutex_t iras = PTHREAD_MUTEX_INITIALIZER;
//felteteles valtozohoz mutex
pthread_mutex_t feltetel = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t felt = PTHREAD_COND_INITIALIZER;
//ferohelyek lockolasara hasznalt mutex
pthread_mutex_t hely[ASZTALOK_SZAMA*FEROHELY];

typedef struct argumentumok{
	unsigned int r; //randomszam generator seedje
	int i; //sorszam
}argumentumok;

int szabad_hely(){
	while(true){
		pthread_mutex_lock(&feltetel);
		for(int i=0;i<ASZTALOK_SZAMA;i++){
			if(pthread_mutex_trylock(&hely[i]) != EBUSY){ //asztal ures
				pthread_mutex_unlock(&feltetel);
				return i;
			}
		}
		for(int i=0;i<ASZTALOK_SZAMA;i++){
			if(pthread_mutex_trylock(&hely[i+ASZTALOK_SZAMA]) != EBUSY){ //1 hely van az asztalnal
				pthread_mutex_unlock(&feltetel);
				return i;
			}
		}
		pthread_cond_wait(&felt, &feltetel);
		pthread_mutex_unlock(&feltetel);
	}
}

void elment(int i){
	//felteteles valtozo feloldasa miutan szabad lesz a hely
    pthread_mutex_lock(&feltetel);
    pthread_mutex_unlock(&hely[i]);
	pthread_cond_signal(&felt);
    pthread_mutex_unlock(&feltetel);

}

//vendeget szimulalo thread
void* vendeg(void* arg){
	argumentumok* tmp = (argumentumok*) arg;
	int i = tmp->i;
	unsigned int *r = &tmp->r;
	
	while(!bezart){
		//beleep
		pthread_mutex_lock(&iras);
		printf("[%d] Belep a menzara\n", i);
        pthread_mutex_unlock(&iras);

		//helyet foglal
		int index = szabad_hely();
        //ha varakozas alatt bezar a menza akkor elmegy
		if(bezart){
			printf("[%d] Hazament\n", i);
			pthread_mutex_unlock(&iras);
			break;
		}
		pthread_mutex_lock(&iras);
		asztalok[index]++;
		printf("[%d] Leul a(z) %d. asztalhoz, ennel %d szabad hely marad\n", i,index , FEROHELY-asztalok[index]);
		pthread_mutex_unlock(&iras);

		//ul valamennyi idot
		sleep(rand_r(r)%3 + 1);

		//felall es hazamegy
		pthread_mutex_lock(&iras);
		
		//szabad lesz egy hely
		asztalok[index]--;
		
		//kiirasok
		printf("[%d] Felall, felszabadul a(z) %d. asztalnal 1 hely, %d szabd hely lesz ennel\n", i, index, FEROHELY-asztalok[index]);
		printf("[%d] Hazamegy\n", i);
		
        pthread_mutex_unlock(&iras);

		if(asztalok[index] == 1){
			elment(index + ASZTALOK_SZAMA);
		}
		else{
			elment(index);
		}


		//var amig visszajon
		sleep(rand_r(r)%3 + 1);
	}
	return NULL;
}

int main(){
	//foszal veletlenszam generatora
	srand(getpid());
	//helyfogalalas
	pthread_t* vendegek = (pthread_t*)malloc(VENDEGEK_SZAMA*sizeof(pthread_t));
	argumentumok* tmp = (argumentumok*)malloc(VENDEGEK_SZAMA*sizeof(argumentumok));

	//idomeres, 10 sec lesz "10 ora"
	struct timespec start, stop;
	clock_gettime(CLOCK_REALTIME, &start);
	printf("Megnyilt a menza!\n");

	//threadek letrehozasa
	for(int i=0;i<VENDEGEK_SZAMA;i++){
		tmp[i].r = rand();
		tmp[i].i = i;
		if(pthread_create(&vendegek[i], NULL, vendeg, (void*) &tmp[i])){
			perror("Pthread_create hiba");
			return 1;
		}
	}

	//"10 ora" megvarasa
	do{
		clock_gettime(CLOCK_REALTIME, &stop);
	}while(stop.tv_sec - start.tv_sec < 10);
	pthread_mutex_lock(&iras);
	bezart = true;
	printf("Bezart a menza\n");
	pthread_mutex_unlock(&iras);

	//threadek bevarasa
	for (int i=0;i<VENDEGEK_SZAMA;i++){
		if(pthread_join(vendegek[i], NULL)){
			perror("Pthread_join hiba");
			return 1;
		}
	}

	//hely felszabaditas
	free(vendegek);
	free(tmp);
	return 0;	
}

