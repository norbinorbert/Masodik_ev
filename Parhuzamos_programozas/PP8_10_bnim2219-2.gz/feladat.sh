#!/bin/bash

n=1000
szalak=2
while true
do
	osszeg=0
	for i in {1..10}
	do
		gyorsitas=`./p $n $szalak | tail -n 1 | cut -d' ' -f 2`
    	osszeg=$((osszeg+gyorsitas))	
	done
	egesz=$((osszeg/1000000))
	tort=""
	if [ `echo $((osszeg/100000)) | cut -c 2` -eq 0 ]
	then
		tort=0
	fi
	tort=${tort}$((osszeg%1000000))
	echo Gyorsitas n=${n}, szalak_szama=${szalak}: $((osszeg/1000000)).${tort}
	n=$((n*2))
	szalak=$((szalak*2))

	if [ $szalak -gt 16 ]
	then
		exit 0
	fi
done
