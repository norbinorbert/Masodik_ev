//Boda Norbert, PP8_10, bnim2219

/*Írjunk szekvenciális illetve párhuzamos programot, mely egy n x n-es mátrixszal reprezentált bittérképre alkalmaz
egy 3 x 3-as élesítő konvolúciós szűrőt, azaz minden egyes értéket helyettesít (egy új, eredménymátrixban) a
konvolúció eredményével, ami a mátrixérték, illetve szomszédainak súlyozott összegét jelenti, a súlyozó
együtthatókat pedig a konvolúció operátora (vagyis az említett 3 x 3-as szűrő) tartalmazza (lásd a példát):
Pl. legyen a szűrő
-1 -1 -1
1/9 x -1 8 -1
-1 -1 -1 (az 1/9-et kiemeltük)
Ekkor a mátrix egy tetszőleges értéke az alábbi módon módosul:
z1 z2 z3
z4 p  z5 ->  q
z6 z7 z8
ahol q = 1/9 x [(-1) x z1+(-1) x z2+(-1) x z3+(-1) x z4+8 x p+(-1)xz5+(-1) x z6+(-1) x z7+(-1) x z8]
pl.
10 20 30   10 20 30
10 20 30-> 10 0  30
10 20 30   10 20 30
mivel 1/9 x [(-1)x10+(-1)x20+(-1)x30+(-1)x10+8x20+(-1)x30+(-1)x10+(-1)x20+(-1)x30]=0Megj.: a mátrix beolvasása vagy generálása, illetve az eredmény kiírása nem számít bele az időmérésbe.*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <omp.h>
#include <time.h>

void konvolucio(int[3][3], int**, int**, int, int, int);

#define MAX_ERTEK 100

int main(int argc, char* argv[]){
	//parameter ellenorzes
	if(argc != 3){
		printf("Helytelen parameterezes!\nHasznalat: %s n\n", argv[0]);
		return 1;
	}
	int n = atoi(argv[1]);
	int m = atoi(argv[2]);
	if(n <= 0){
		printf("A parameter 0-nal nagyobb szam kell, hogy legyen\n");
		return 1;
	}
	srand(getpid());
	
	//konvolucios szuro generalasa
	int szuro[3][3];
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			szuro[i][j] = rand() % MAX_ERTEK;
		}
	}
	
	//kezdo matrix generalasa
	int** eredeti = (int**)malloc(n*sizeof(int*));
	int** eredmeny = (int**)calloc(n,sizeof(int*));
	for(int i=0;i<n;i++){
		eredeti[i] = (int*)malloc(n*sizeof(int));
		eredmeny[i] = (int*)calloc(n,sizeof(int));
	}
	
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			eredeti[i][j] = rand() % MAX_ERTEK;
		}
	}
	/*
	printf("Konvolucios szuro:\n");
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			printf("%d ", szuro[i][j]);
		}
		printf("\n");
	}
	*/
	/*
	printf("\nEredeti matrix\n");
	for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            printf("%d ", eredeti[i][j]);
        }
        printf("\n");
    }
	*/
	//idomeres kezdete
	struct timespec start, stop;
	clock_gettime(CLOCK_REALTIME, &start);	

	//konvolucio elvegzese
	for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
			konvolucio(szuro, eredeti, eredmeny, i, j, n);
        }
    }
	
	//szekvencialis kod vege
	clock_gettime(CLOCK_REALTIME, &stop);
	long unsigned int ns_sz=(stop.tv_sec - start.tv_sec) * 1000000000 + stop.tv_nsec - start.tv_nsec;
	printf("\nSzekvencialis ido: %lu ns (%lf s)\n", ns_sz, ns_sz*1.0/1000000000);

	/*
	printf("\nEredmeny matrix szekvencialis kod utan\n");
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            printf("%d ", eredmeny[i][j]);
        }
        printf("\n");
    }
*/
///////////////////////////////////////////////////////////////////////////////////////////////////
	for(int i=0;i<n;i++){
		free(eredmeny[i]);
	}
	free(eredmeny);
	eredmeny = (int**)calloc(n,sizeof(int*));
    for(int i=0;i<n;i++){
        eredmeny[i] = (int*)calloc(n,sizeof(int));
    }

	//idomeres kezdete
    clock_gettime(CLOCK_REALTIME, &start);

#	pragma omp parallel num_threads(m) default(none)\
	shared(szuro, eredmeny, eredeti, n)
{
    //konvolucio elvegzese
#	pragma omp for
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            konvolucio(szuro, eredeti, eredmeny, i, j, n);
        }
    }
}
    //parhuzamos kod vege
    clock_gettime(CLOCK_REALTIME, &stop);
	long unsigned int ns=(stop.tv_sec - start.tv_sec) * 1000000000 + stop.tv_nsec - start.tv_nsec;
    printf("\nParhuzamos ido: %lu ns (%lf s)\n", ns, ns*1.0/1000000000);
/*
	printf("\nEredmeny matrix parhuzamos kod utan(ugyanaz kene legyen)\n");
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            printf("%d ", eredmeny[i][j]);
        }
        printf("\n");
    }
*/
	//hely felszabaditas
	printf("Gyorsitas: %lf\n", ((double)ns_sz)/ns);
	printf("Gyorsitas*100000(shell_scriptnek_kell): %d\n", (int)((((double)ns_sz)/ns)*100000));
	for(int i=0;i<n;i++){
        free(eredeti[i]);
        free(eredmeny[i]);
    }
	free(eredeti);
	free(eredmeny);
	return 0;
}

void konvolucio(int szuro[3][3], int** eredeti, int** eredmeny, int sor, int oszlop, int n){
	if(n == 1){
		eredmeny[0][0] = eredeti[0][0] * szuro[1][1];
		return;
	}
	if(sor==0 && oszlop==0){
		for(int i=1;i<3;i++){
            for(int j=1;j<3;j++){
                eredmeny[sor][oszlop] += szuro[i][j]*eredeti[sor-1+i][oszlop-1+j];
            }
        }
	}
	else if(sor==n-1 && oszlop==n-1){
		for(int i=0;i<2;i++){
            for(int j=0;j<2;j++){
                eredmeny[sor][oszlop] += szuro[i][j]*eredeti[sor-1+i][oszlop-1+j];
            }
        }
	}
	else if(sor==0){
		for(int i=1;i<3;i++){
            for(int j=0;j<3;j++){
                eredmeny[sor][oszlop] += szuro[i][j]*eredeti[sor-1+i][oszlop-1+j];
            }
        }
	}
	else if(sor==n-1){
		for(int i=0;i<2;i++){
            for(int j=0;j<3;j++){
                eredmeny[sor][oszlop] += szuro[i][j]*eredeti[sor-1+i][oszlop-1+j];
            }
        }
	}
	else if(oszlop==0){
		for(int i=0;i<3;i++){
            for(int j=1;j<3;j++){
                eredmeny[sor][oszlop] += szuro[i][j]*eredeti[sor-1+i][oszlop-1+j];
            }
        }
	}
	else if(oszlop==n-1){
		for(int i=0;i<3;i++){
            for(int j=0;j<2;j++){
                eredmeny[sor][oszlop] += szuro[i][j]*eredeti[sor-1+i][oszlop-1+j];
            }
        }
	}
	else{
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				eredmeny[sor][oszlop] += szuro[i][j]*eredeti[sor-1+i][oszlop-1+j];
			}
		}
	}
}
