//Boda Norbert, Lab1, bnim2219

/*Adott egy (p1 x p2 x p3)2-es, 0 és 100 közötti egészeket tartalmazó mátrix (ahol p1, p2 és p3 nem feltétlenül
különböző prímszámok). Ennek a mátrixnak az elemeit fogjuk összeadni, különbözőképpen osztva szét a mátrixot a
folyamatok közt.

Írjunk segédprogramot, mely paraméterként kapja a p1, p2, p3 számokat, egy input.dat nevű állományba
írja a mátrix méretét (pontosabban p1, p2, p3-t) és véletlenszerűen generált elemeit (azért, hogy több
programváltozat is ugyanazzal a mátrixszal dolgozhasson).

A mátrixot m x n-es méretű téglalapokra osztjuk fel: ajánljuk fel a felhasználónak, hogy válasszon a lehetséges
méretek közül (m és n bármelyike az alábbi értékeket veheti fel: 1,p1, p2, p3, p1 x p2, p1 x p3, p2 x p3, p1 x p2 x p3). Az  így kapott (p1 x p2 x p3)/m x (p1 x p2 x p3)/ n db. téglalapot osszuk szét k folyamat között, nagyjából egyenletes módon (k értékét paraméterként adjuk meg).

Miután a főprogram elvégezte a felosztáshoz szükséges számításokat, csak azután hozza létre a k-1
gyerekfolyamatot (a k. folyamat maga a szülő lesz). A k folyamat mindegyike végezze el a mátrixértékek összeadását
a számára kijelölt téglalapokban, majd a részösszeget írja be egy, a k folyamat által közösen használt pipe-ba.

Végül, miután minden gyerekfolyamat befejeződött, a főprogram összeadja a részösszegeket, hogy megkapja a
végső eredményt.

időmérés: mérjük meg az összeg kiszámításához használt időt különböző (legalább háromféle) felosztás esetén,
illetve használjunk minden konkrét felosztás esetén két különböző k értéket. (Figyeljük meg, hogy az, hogy rövidebb vagy hosszabb időt kaptunk, megegyezik-e azzal, ahogy azt logikusan előre elképzeltük.)*/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdbool.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <time.h>

typedef struct KOORD{
		int x,y;
}KOORD;

//ellenorzi, ha a "szam" valozo megfelel a felada kerelmenek
bool Lehetseges(int p1, int p2, int p3, int szam){
	return (szam==p1 || szam==p2 || szam==p3 || szam==p1*p2 || szam ==p1*p3 || szam==p2*p3 || szam==p1*p2*p3);
}

int main(int argc, char* argv[]){
	//parameter ellenorzes
	if(argc != 2){
		fprintf(stderr, "Helyelen parameerezes!\nHasznalat: %s k\n", argv[0]);
		return 1;
	}
	if(atoi(argv[1]) <= 0){
		fprintf(stderr, "%s nem pozitiv egesz szam\n", argv[1]);
		return 1;
	}
	
	//input file megnyitasa es a matrix meretenek kiolvasasa
	int in = open("input.dat", O_RDONLY);
	int p1, p2, p3;
	read(in, &p1, sizeof(int));
	read(in, &p2, sizeof(int));
	read(in, &p3, sizeof(int));

	//m*n-es teglalap mereteinek beolvasasa
	int n, m;
	printf("Valassz n es m erteket. Lehetseges ertekek: %d %d %d %d %d %d %d\n", p1, p2, p3, p1*p2, p1*p3, p2*p3, p1*p2*p3);
	while(true){
		printf("n = ");
		scanf("%d", &n);
		if(!Lehetseges(p1, p2, p3, n)){
			printf("%d nincs a felso ertekek kozott, valassz uj erteket!\n", n);
			continue;
		}
		break;
	}
	while(true){
		printf("m = ");
		scanf("%d", &m);
		if(!Lehetseges(p1, p2, p3, m)){
			printf("%d nincs a felso ertekek kozott, valassz uj erteket!\n", m);
			continue;
		}
		break;
	}

	//matrix letrehozasa, illetve ertekek kiolvasasa
	int** matrix = (int**)malloc(p1*p2*p3*sizeof(int*));
	for(int i=0;i<p1*p2*p3;i++){
		matrix[i] = (int*)malloc(p1*p2*p3*sizeof(int));
	}
	for(int i=0;i<p1*p2*p3;i++){
		for(int j=0;j<p1*p2*p3;j++){
			read(in, &matrix[i][j], sizeof(int));
		}
	}

	int k = atoi(argv[1]);

	//pipeok lerehozasa
	int privat[k][2];
	int kozos[2];
	for(int i=0;i<k;i++){
		if(pipe(privat[i]) < 0){
			perror("Pipe hiba!\n");
			return 1;
		}
	}
	if(pipe(kozos) < 0){
		perror("Pipe hiba!\n");
		return 1;
	}

	//matrix felosztasa
	int x=0, y=0;
	int szamlalo = 0;
	while(x<p1*p2*p3 && y<p1*p2*p3){
		KOORD temp;
		temp.x = x;
		temp.y = y;
		write(privat[szamlalo][1], &temp, sizeof(temp));
		
		y += n;
		szamlalo++;
		
		if(y>=p1*p2*p3){
			y = 0;
			x+=m;
		}
					
		if(szamlalo == k){
			szamlalo = 0;
		}
	}
	
	//idomeres kezdese
	struct timespec start, stop;
	clock_gettime(CLOCK_REALTIME, &start);

	//gyerekfolyamatok
	for(int i=0; i < k - 1; i++){
		switch(fork()){
			case -1: perror("Fork hiba!\n");
			case 0:{
				//folos pipeok bezarasa
				for(int j=0;j<k-1;j++){
					if(j!=i){
						close(privat[j][0]);
						close(privat[j][1]);
					}
				}
				close(privat[i][1]);
				close(kozos[0]);

				int reszosszeg = 0;
				KOORD koord;
				while(read(privat[i][0], &koord, sizeof(koord)) > 0 ){
					for(int i=koord.x;i<koord.x+m;i++){
						for(int j=koord.y;j<koord.y+n;j++){
							//for(int k=0;k<1000;k++){}
								reszosszeg+=matrix[i][j];
						}
					}
				}

				//reszosszeg beirasa 
				write(kozos[1], &reszosszeg, sizeof(int));

				//maradek pipe bezarasa
				close(privat[i][1]);
				close(kozos[0]);
				return 0;
			}
		}
	}

	//folos pipeok bezarasa
	for(int i=0;i<k-1;i++){
		close(privat[i][0]);
		close(privat[i][1]);
	}
	close(privat[k-1][1]);
	close(kozos[1]);

	int osszeg = 0;
	int reszosszeg = 0;
	KOORD temp;
	while(read(privat[k-1][0], &temp, sizeof(temp)) > 0 ){
			for(int i=temp.x;i<temp.x+m;i++){
				for(int j=temp.y;j<temp.y+n;j++){
					//	for(int k=0;k<1000;k++){}
					osszeg += matrix[i][j];
				}
			}
	}
	
	close(privat[k-1][0]);

	//gyerekfolyamatok bevarasa
    for(int i=0;i<k-1;i++){
        wait(NULL);
    }
	//eredmenyek kiolvasasa
    while(read(kozos[0], &reszosszeg, sizeof(int)) > 0){
	//for(int k=0;k<1000;k++){}	
        osszeg += reszosszeg;
    }
	close(kozos[0]);

	//idomeres vege
	clock_gettime(CLOCK_REALTIME, &stop);

	//eredmeny es ido kiirasa
	long unsigned int e_time=(stop.tv_sec - start.tv_sec) * 1000000000 + stop.tv_nsec - start.tv_nsec;
	printf("Osszeg: %d. Ido %lu ns (%lf s)\n", osszeg, e_time, e_time*1.0/1000000000);
	
	//lefoglalt memoria felszabaditasa
	for(int i=0;i<p1*p2*p3;i++){
		free(matrix[i]);
	}
	free(matrix);

	//bemeneti file bezarasa
	close(in);
	return 0;
}
