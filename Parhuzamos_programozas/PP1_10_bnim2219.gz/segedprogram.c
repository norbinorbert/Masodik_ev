//Boda Norbert, Lab1, bnim2219

/*Adott egy (p1 x p2 x p3)^2-es, 0 és 100 közötti egészeket tartalmazó mátrix (ahol p1, p2 és p3 nem feltétlenül különböző prímszámok). Ennek a mátrixnak az elemeit fogjuk összeadni, különbözőképpen osztva szét a mátrixot a folyamatok közt.

Írjunk segédprogramot, mely paraméterként kapja a p1, p2, p3 számokat, egy input.dat nevű állományba írja a mátrix méretét (pontosabban p1, p2, p3-t) és véletlenszerűen generált elemeit (azért, hogy több programváltozat is ugyanazzal a mátrixszal dolgozhasson).

A mátrixot m x n-es méretű téglalapokra osztjuk fel: ajánljuk fel a felhasználónak, hogy válasszon a lehetséges méretek közül (m és n bármelyike az alábbi értékeket veheti fel: 1,p1, p2, p3, p1 x p2, p1 x p3, p2 x p3, p1 x p2 x p3). Az így kapott (p1 x p2 x p3)/m x (p1 x p2 x p3)/ n db. téglalapot osszuk szét k folyamat között, nagyjából egyenletes módon (k értékét paraméterként adjuk meg).

Miután a főprogram elvégezte a felosztáshoz szükséges számításokat, csak azután hozza létre a k-1 gyerekfolyamatot (a k. folyamat maga a szülő lesz). A k folyamat mindegyike végezze el a mátrixértékek összeadását a számára kijelölt téglalapokban, majd a részösszeget írja be egy, a k folyamat által közösen használt pipe-ba.

Végül, miután minden gyerekfolyamat befejeződött, a főprogram összeadja a részösszegeket, hogy megkapja a végső eredményt.*/

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <unistd.h>
#include <fcntl.h>

//megnezi ha egy szam prim_e
bool Prim(int Szam){
	if(Szam == 0 || Szam == 1){
		return false;
	}
	else if(Szam % 2 == 0){
		return (Szam == 2);
	}
	else if(Szam <= 5){
		return true;
	}
	else if((Szam - 1) % 6 != 0 && (Szam + 1) % 6 != 0){
		return false;
	}
	else{
		int gyok = sqrt(Szam);
		for(int i=3; i<=gyok; i+=2){
			if(Szam % i == 0){
				return false;
			}
		}
	}
	return true;
}

int main(int argc, char* argv[]){
	//parameter ellenorzes
	if(argc != 4){
		fprintf(stderr, "Helytelen parameterezes!\nHasznalat: %s p1 p2 p3\n", argv[0]);
		return 1;
	}
	for(int i=1;i<4;i++){
		int szam = atoi(argv[i]);
		if(szam < 0){
			fprintf(stderr, "%s nem szam\n", argv[i]);
			return 1;
		}
		if(!Prim(szam)){
			fprintf(stderr, "%s nem prim\n", argv[i]);
			return 1;
		}
	}
	//random szam generator inicializalasa
	srand(getpid());
	
	//kimeneti file megnyitasa
    int out = open("input.dat", O_WRONLY | O_CREAT, 0644);
    if(out < 0){
    	fprintf(stderr, "Hiba a binaris allomany letrehozasakor\n");
    	return 1;
    }

	//matrix meretenek kiszamitasa
	int p1 = atoi(argv[1]);
	int p2 = atoi(argv[2]);
	int p3 = atoi(argv[3]);
	int meret = p1 * p2 * p3;
	
	//parameterek fileba irasa
	write(out, &p1, sizeof(int));
	write(out, &p2, sizeof(int));
    write(out, &p3, sizeof(int));

	//matrix elemeinek generalasa es beirasa
	for(int i=0;i<meret;i++){
		for(int j=0;j<meret;j++){
			int random = rand()%101; 
			write(out, &random, sizeof(int));
		}
	}
	close(out);
	return 0;
}
