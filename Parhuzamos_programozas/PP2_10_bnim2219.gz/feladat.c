//Boda Norbert, Lab2, bnim2219

/*Írjunk programot, amely bekér egy (n) természetes számot, és egy n x n-es mátrix prímszámokkal való feltöltését
hajtja végre a következőképpen: a program létrehoz n szálat, minden szál a sorszámának függvényében, a mátrix
ennek megfelelő oszlopát elkezdi feltölteni prímszámokkal ( (sorszám-1)*10 -től indulva, pl. az első szál által beírt
első prímszám 2 lesz, a második esetében 11, stb.).

Amint egy szál feltöltötte a neki megfelelő oszlop összes elemét,

-kiírja a sorszámát, a legkisebb és legnagyobb beírt prímszámot,
-kiírja, hogy hányadiknak fejezte be a munkát (egy, a szálak által, megosztva használt változót növelve)
-kiírja azt is, hogy mennyi időbe telt az oszlop kitöltése (ezredmásodpercekben vagy nanoszekundumokban mérve),
-majd befejeződik.

A főszál megvárja, hogy az összes szál befejeződjön, csupán akkor írja ki a mátrixot és fejeződik be, amikor a mátrix
minden oszlopa teljesen ki van töltve.

Kölcsönös kizárás mutexek segítségével:
-a több szál által megosztva használt változóhoz való hozzáféréskor biztosítsuk a kölcsönös kizárást.
-általában véve, a képernyőre való íráskor, amennyiben van olyan kimenet is, ami többsoros, használjunk egy
mutex változót minden egyes kiírásnál (ugyanazt a mutexet lock-oljuk minden szálban), hogy a kimenetek ne
keveredjenek (ha csak egysoros kiírásaink vannak, akkor ez nem szükséges)*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include <pthread.h>
#include <unistd.h>
//megnezi ha a parameter prim
bool Prim(int Szam){
	if(Szam == 0 || Szam == 1){
		return false;
	}
	else if(Szam % 2 == 0){
		return (Szam == 2);
	}
	else if(Szam <= 5){
		return true;
	}
	else if((Szam - 1) % 6 != 0 && (Szam + 1) % 6 != 0){
		return false;
	}
	else{
		int gyok = sqrt(Szam);
		for(int i=3; i<=gyok; i+=2){
			if(Szam % i == 0){
				return false;
			}
		}
	}
	return true;
}

//threadeknek atadott informaciok structban lesznek tarolva
typedef struct {
		int** matrix;
		int oszlop;
		int n;
}argumentumok;

//globalis valtozok
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
int befejezte = 0;
pthread_mutex_t b = PTHREAD_MUTEX_INITIALIZER;
struct timespec start;
//threadek altal hasznalt fuggveny
void* t(void* arg){
	argumentumok* tmp = (argumentumok*) arg;
	int szam = tmp->oszlop*10;
	int legkisebb = 0, legnagyobb = 0;
	
	struct timespec stop;
	
	//matrix oszlopanak feltoltese prim szamokkal
	for(int i=0;i<tmp->n;i++){
		while(!Prim(szam)){
			szam++;
		}
		if(legkisebb==0){
			legkisebb = szam;
		}
		tmp->matrix[i][tmp->oszlop] = szam;
		legnagyobb = szam;
		szam++;
	}

	//szukseges informaciok kiirasa, mutex lockot hasznalva
	pthread_mutex_lock(&b);
	clock_gettime(CLOCK_REALTIME, &stop);

	int tmp2 = befejezte++;
	pthread_mutex_unlock(&b);
	
	pthread_mutex_lock(&m);

	printf("Sorszam: %d. Legkisebb: %d. Legnagyobb: %d\n", tmp->oszlop, legkisebb, legnagyobb);
	printf("Befejezesi sorszam: %d\n", tmp2);
	printf("Ido: %lu ns\n\n", (stop.tv_sec-start.tv_sec)*1000000000 + stop.tv_nsec - start.tv_nsec);
	
	pthread_mutex_unlock(&m);
	return NULL;
}

int main(){
	//matrix meretenek beolvasasa
	int n;
	printf("n = ");
	scanf("%d", &n);

	//matrix lefoglalalsa
	int** matrix = (int**)malloc(n*sizeof(int*));
	for(int i=0;i<n;i++){
		matrix[i] = (int*)malloc(n*sizeof(int));
	}

	//threadeket tartalmazo tomb
	pthread_t* th = (pthread_t*)malloc(n*sizeof(pthread_t));
	
	//argumentumokat tartalmazo tomb
	argumentumok* tmp = (argumentumok*)malloc(n*sizeof(argumentumok));

clock_gettime(CLOCK_REALTIME, &start);

	//threadek inditasa
	for(int i=0;i<n;i++){
		tmp[i].matrix = matrix;
		tmp[i].oszlop = i;
		tmp[i].n = n;
		if(pthread_create(&th[i], NULL, t, (void*) &tmp[i]) != 0){
			perror("pthread_create hiba\n");
			return 1;
		}
	}
	
	//threadek bevarasa
	for(int i=0;i<n;i++){
		if(pthread_join(th[i], NULL) != 0){
			perror("pthread_join hiba\n");
			return 1;
		}
	}

	//thread es argumentum tombok felszabaditasa
	free(th);
	free(tmp);

	//matrix kiirasa
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			printf("%d ", matrix[i][j]);
		}
		printf("\n");
	}

	//matrix felszabaditasa
	for(int i=0;i<n;i++){
		free(matrix[i]);
	}
	free(matrix);

	return 0;
}
