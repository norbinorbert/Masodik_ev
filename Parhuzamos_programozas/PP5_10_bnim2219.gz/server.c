// Boda Norbert, Lab5_10, bnim2219

/*A kliens egy állománynevet és egy karaktert küld a szervernek, a szerver pedig visszaküldi a kliensnek az illető
állománynak a megadott karakterrel kezdődő sorait és ezen sorok számát, és az állomány sorainak a számát, vagy
pedig egy hibaüzenetet, amennyiben az állomány nem létezik.
A kérés prioritása egyezzen meg a küldött betű ábécében elfoglalt helyének sorszámával (pl. a vagy A prioritása 1, a
b vagy B karakteré 2, stb.).
A kiírásokból lehessen követni, hogy mi történik:
a kliens írjon ki szöveget az üzenet küldésnél (írja ki a kérés prioritását is), és írja ki a kapott választ (minden
sorban szerepeljen az azonosítója is)
a szerver írjon ki üzenetet, ha kérést kap (kitől, mi a kérés, kérés prioritása), és a válasz küldésekor (csak azt,
hogy kinek küld választ)
Gondoskodjunk a szerver leállításáról (pl. egy bizonyos számú kérés kiszolgálása után vagy egy bizonyos idő eltelte
után, esetleg egy speciális üzenet hatására).*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <mqueue.h>
#include <pthread.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string.h>
#include "seged.h"

void* t(void* arg){
	Uzenet* tmp = (Uzenet*) arg;
	pid_t pid = tmp->pid;
	char karakter = tmp->karakter;

	//kliens uzenetsor megnyitasa
	char name[20];
	sprintf(name, "/%d_mq", pid);
	mqd_t kl_usor = mq_open(name, O_WRONLY);
	if(kl_usor == -1){
		perror("mq_open hiba - thread");
		return NULL;
	}
	//parancs elvegzese popen segitsegevel
	char command[100];
	sprintf(command, "./seged.sh %c %s", karakter, tmp->allomany);
	FILE* out = popen(command, "r");

	char buf[1024];
	//valasz kuldese soronkent
	printf("[Server] Valaszt kuld [%d]-nek\n", pid);
	fflush(NULL);
	while(fgets(buf, sizeof(buf), out)){
		if(mq_send(kl_usor, buf, sizeof(buf), 0) < 0){
			perror("mq_send hiba");
			return NULL;
		}
	}
	pclose(out);
	//uzenetsor bezarasa
	if(mq_close(kl_usor) < 0){
		perror("mq_close hiba");
	}
	return NULL;
}

#define MAX_THREADS 4

int main(){
	pthread_t th[MAX_THREADS];
	Uzenet uzenetek[MAX_THREADS];

	//uzenetsor letrehozasa
	struct mq_attr attr;
	attr.mq_maxmsg = 10;
	attr.mq_msgsize = sizeof(Uzenet);
	mqd_t s_usor = mq_open("/bnim2219", O_RDONLY|O_CREAT, 0600, &attr);
	if(s_usor == -1){
		perror("mq_open hiba - server uzenetsor letrehozasa");
		return 1;
	}

	int i=0;
	unsigned int prio;
	//uzenetek olvasasa es szalak inditasa
	while(i<MAX_THREADS && mq_receive(s_usor, (char*) &uzenetek[i], sizeof(Uzenet), &prio) != -1){
		printf("[Server] Kerest kapott [%d]-tol, prioritas: %d\n", uzenetek[i].pid, prio);
		fflush(NULL);
		if(pthread_create(&th[i], 0, t, (void*) &uzenetek[i]) != 0){
			perror("pthread_create hiba");
			return 1;
		}
		i++;
	};
	//szalak bevarasa
	for(int i=0;i<MAX_THREADS;i++){
		if(pthread_join(th[i], NULL) != 0){
			perror("pthread_join hiba");
			return 1;
		}
	}
	//uzenetsor bezarasa
	if(mq_close(s_usor) <0){
		perror("mq_close hiba");
		return 1;
	}
	if(mq_unlink("/bnim2219") <0){
		perror("mq_unlink hiba");
		return 1;
	}
	return 0;
}       

