// Boda Norbert, Lab5_10, bnim2219

/*A kliens egy állománynevet és egy karaktert küld a szervernek, a szerver pedig visszaküldi a kliensnek az illető
állománynak a megadott karakterrel kezdődő sorait és ezen sorok számát, és az állomány sorainak a számát, vagy
pedig egy hibaüzenetet, amennyiben az állomány nem létezik.
A kérés prioritása egyezzen meg a küldött betű ábécében elfoglalt helyének sorszámával (pl. a vagy A prioritása 1, a
b vagy B karakteré 2, stb.).
A kiírásokból lehessen követni, hogy mi történik:
a kliens írjon ki szöveget az üzenet küldésnél (írja ki a kérés prioritását is), és írja ki a kapott választ (minden
sorban szerepeljen az azonosítója is)
a szerver írjon ki üzenetet, ha kérést kap (kitől, mi a kérés, kérés prioritása), és a válasz küldésekor (csak azt,
hogy kinek küld választ)
Gondoskodjunk a szerver leállításáról (pl. egy bizonyos számú kérés kiszolgálása után vagy egy bizonyos idő eltelte
után, esetleg egy speciális üzenet hatására).*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <mqueue.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string.h>
#include "seged.h"

int main(int argc, char* argv[]){
	//parameter ellenorzes
	if(argc % 2 != 1 || argc == 1){
		printf("Helytelen hasznalat!\nHelyesen: %s karakter allomanynev [karakter allomanynev...]\n", argv[0]);
		return 1;
	}
	pid_t pid = getpid();
	
	//kimeneti file megnyitasa
	char name[20];
	sprintf(name, "%d_out.dat", pid);
	FILE* out = fopen(name, "w");

	//server uzenetsor megnyitasa
	mqd_t s_usor = mq_open("/bnim2219", O_WRONLY);
	if(s_usor == -1){
		perror("mq_open hiba - kliens - server");
		return 1;
	}

	char buf[1024];
	//kliens uzenetsoranak letrehozasa
    struct mq_attr attr;
    attr.mq_maxmsg = 10;
    attr.mq_msgsize = sizeof(buf);
	char kl_usor_nev[20];
    sprintf(kl_usor_nev, "/%d_mq", pid);
    mqd_t kl_usor = mq_open(kl_usor_nev, O_RDONLY|O_CREAT, 0600, &attr);
    if(kl_usor == -1){
        perror("mq_open hiba - kliens - kliens");
        return 1;
    }

	//uzenetek kuldese
	for(int i=1;i<argc;i=i+2){
		char karakter = *argv[i];
		//prioritas meghatarozasa
	    unsigned int prio;
    	if(karakter <= 'Z'){
        	prio = karakter - 'A' + 1;
	    }
    	else{
        	prio = karakter - 'a' + 1;
	    }
	
		Uzenet uzenet;
		uzenet.karakter = karakter;
		strcpy(uzenet.allomany, argv[i+1]);
		uzenet.pid = pid;
		
		printf("[%d] Uzenetet kuldi, prioritas: %d\n", pid, prio);
		fflush(NULL);
		if(mq_send(s_usor, (char*) &uzenet, sizeof(Uzenet), prio) < 0){
			perror("mq_send hiba");
			return 1;
		}

		char hiba[100];
		sprintf(hiba, "%s nevu allomany nem letezik\n", uzenet.allomany);
		int szam = -1;
		while(mq_receive(kl_usor, buf, sizeof(buf), &prio) != -1){
			fprintf(out, "[%d] %s", pid, buf);
			if((atoi(buf)>=szam && szam != -1) || (strcmp(buf, hiba) == 0)){
				break;
			}
			if(atoi(buf) > 0 || strcmp(buf, "0\n") == 0){
				szam = atoi(buf);
			}
		}
		printf("[%d] Kiolvasta a valaszt es beirta az allomanyba\n", pid);	
		fflush(NULL);
	}

	//uzenetsorok bezarasa
	if(mq_close(s_usor) < 0){
		perror("mq_close hiba");
		return 1;
	}
	if(mq_close(kl_usor) < 0){
		perror("mq_close hiba");
		return 1;
	}
	if(mq_unlink(kl_usor_nev) < 0){
		perror("mq_unlink hiba");
		return 1;
	}

	fclose(out);
	return 0;
}

