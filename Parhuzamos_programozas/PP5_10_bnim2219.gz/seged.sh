#Boda Norbert, Lab5_10, bnim2219

#A kliens egy állománynevet és egy karaktert küld a szervernek, a szerver pedig visszaküldi a kliensnek az illető
#állománynak a megadott karakterrel kezdődő sorait és ezen sorok számát, és az állomány sorainak a számát, vagy
#pedig egy hibaüzenetet, amennyiben az állomány nem létezik.
#A kérés prioritása egyezzen meg a küldött betű ábécében elfoglalt helyének sorszámával (pl. a vagy A prioritása 1, a
#b vagy B karakteré 2, stb.).
#A kiírásokból lehessen követni, hogy mi történik:
#a kliens írjon ki szöveget az üzenet küldésnél (írja ki a kérés prioritását is), és írja ki a kapott választ (minden
#sorban szerepeljen az azonosítója is)
#a szerver írjon ki üzenetet, ha kérést kap (kitől, mi a kérés, kérés prioritása), és a válasz küldésekor (csak azt,
#hogy kinek küld választ)
#Gondoskodjunk a szerver leállításáról (pl. egy bizonyos számú kérés kiszolgálása után vagy egy bizonyos idő eltelte
#után, esetleg egy speciális üzenet hatására).

if [ ! -e $2 ] || [ ! -f $2 ]
then
	echo "$2 nevu allomany nem letezik"
	exit 1
fi

grep "^$1" $2
grep "^$1" $2|wc -l
wc -l $2 | cut -d' ' -f1














