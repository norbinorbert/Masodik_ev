#ifndef SEGED_H
#define SEGED_H

typedef struct{
	char karakter;
	char allomany[50];
	pid_t pid;
}Uzenet;

#endif
