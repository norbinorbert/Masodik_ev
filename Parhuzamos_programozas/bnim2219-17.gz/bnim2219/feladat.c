#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <unistd.h>

int main(int argc, char* argv[]){
    if(argc != 3){
        printf("Helytelen parameterezes!\nHasznalat:%s n p\n", argv[0]);   
        return 1;
    }
    int n = atoi(argv[1]);
    int p = atoi(argv[2]);
    if(n <= 0 || p <= 0){
        printf("n es p nagyobb kell legyen, mint 0\n");
        return 1;
    }

//konyvek generalasa
    int konyvek[n];
    int* seed;
    srand(getpid());
    #pragma omp parallel default(none)\
    shared(konyvek, seed, n, p) 
{
    int threads = omp_get_num_threads();
    if(threads < p){
        threads = p;
    }
    #pragma omp single
    {
        seed = (int*)malloc(threads*sizeof(int));
        for(int i=0;i<threads;i++){
            seed[i] = rand();
        }
    }

    int rank = omp_get_thread_num();
    #pragma omp for
    for(int i=0;i<n;i++){
        konyvek[i] = rand_r(&seed[rank])%9000 + 1000;
    }

}
    FILE* kepregenyek = fopen("kepregenyek", "w");
    for(int i=0;i<n;i++){
        fprintf(kepregenyek, "%d\n", konyvek[i]);
    }
    

//szekvencialis resz
    int* kategoriak = (int*)calloc(10, sizeof(int));
    int* foliazott = (int*)calloc(n, sizeof(int));
    double start = omp_get_wtime();
    for(int i=0;i<n;i++){
        int kategoria = konyvek[i]/1000;
        kategoriak[kategoria]++;
        //for(int j=0;j<1000;j++){}
        foliazott[i] = konyvek[i] * 10 + konyvek[i]/1000;
    }
    double end = omp_get_wtime();
    double sz_ido = end - start;

    int ossz = 0;
    printf("Szekvencialis ido: %lf\n", sz_ido);
    for(int i=1;i<10;i++){
        ossz += kategoriak[i];
        printf("Kategoria %d: %d konyv\n", i, kategoriak[i]);
    }
    printf("Osszesen: %d\n", ossz);

    FILE* sz = fopen("folias_sz", "w");
    for(int i=0;i<n;i++){
        fprintf(sz, "%d\n", foliazott[i]);
    }


//parhuzamos resz
    free(kategoriak);
    kategoriak = (int*)calloc(10, sizeof(int));
    free(foliazott);
    foliazott = (int*)calloc(n, sizeof(int));
    start = omp_get_wtime();
   
    #pragma omp parallel for num_threads(p) default(none)\
    shared(kategoriak, foliazott, n, konyvek)
    for(int i=0;i<n;i++){
        int kategoria = konyvek[i]/1000;
        #pragma omp atomic
        kategoriak[kategoria]++;
        //for(int j=0;j<1000;j++){}
        foliazott[i] = konyvek[i] * 10 + konyvek[i]/1000;
    }

    end = omp_get_wtime();
    double p_ido = end - start;

    ossz = 0;
    printf("Parhuzamos ido: %lf\n", p_ido);
    for(int i=1;i<10;i++){
        ossz += kategoriak[i];
        printf("kategoria %d: %d konyv\n", i, kategoriak[i]);
    }
    printf("Osszesen: %d\n", ossz);

    FILE* par = fopen("folias_p", "w");
    for(int i=0;i<n;i++){
        fprintf(par, "%d\n", foliazott[i]);
    }

    printf("Gyorsitas: %lf\n", sz_ido/p_ido);
    
    printf("Hatekonysag: %lf\n", sz_ido/(p_ido * p));
    
    FILE* rend = fopen("rendezett", "w");

    int* vastagok = (int*)calloc(p, sizeof(int));
    int nyertes = 0, m = (n+81)/10;
    char uzenet[4];
    int* polcok = (int*)calloc(m*10, sizeof(int));
    int* poziciok = (int*)calloc(10, sizeof(int));
    for(int i=2;i<10;i++){
        poziciok[i] = poziciok[i-1] + kategoriak[i-1];
        while(poziciok[i]%10 != 0){
            poziciok[i]++;
        }
    }
    #pragma omp parallel num_threads(p) default(none)\
    shared(vastagok, n, uzenet, nyertes, konyvek, p, seed, m, polcok, poziciok, foliazott, rend)
{    
    int rank = omp_get_thread_num();
    #pragma omp for
    for(int i=0;i<n;i++){
        int vastagsag = konyvek[i]%1000;
        if(vastagsag == 0){
            vastagsag = 1000;
        }
        if(vastagok[rank] < vastagsag){
            vastagok[rank] = vastagsag;
        }
    }
    #pragma omp barrier
    if(rank == 0){
        int max = vastagok[0];
        nyertes = 0;
        for(int i=1;i<p;i++){
            if(vastagok[i] > max){
                max = vastagok[i];
                nyertes = i;
            }
        }
        printf("[Tulaj] Legvastagabb konyv: %d. Megtalalo: %d\n", max, nyertes);
        for(int i=0;i<3;i++){
            uzenet[i] = rand_r(&seed[rank]) % 26 + 'a';
        }
        uzenet[3] = '\0';
    }
    #pragma omp barrier
    if(rank == nyertes && rank != 0){
        printf("[%d] Nyeremeny: %s\n", rank, uzenet);
    }
    
    #pragma omp for schedule(dynamic)
    for(int i=0;i<n;i++){
        int kategoria = foliazott[i] % 10;
        int index;
        #pragma omp critical
        {
            index = poziciok[kategoria];
            poziciok[kategoria]++;
        }
        polcok[index] = foliazott[i];

    }
    #pragma omp barrier
    if(rank == 0){
        for(int i=0;i<10*m;i++){
            if(i%10==0){
                fprintf(rend, "\n");
            }
            fprintf(rend, "%d ", polcok[i]);
        }
        fprintf(rend, "\n");
    }
}

    fclose(sz);
    fclose(par);
    fclose(kepregenyek);
    fclose(rend);
    free(seed);
    free(kategoriak);
    free(vastagok);
    free(polcok);
    return 0;
}
