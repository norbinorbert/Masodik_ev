//Boda Norbert, Lab3_10, bnim2219

/*Irjunk programot, mely 3 szálat hoz létre (a +1, azaz 19. bónuszpontért lehet általánosítani N szálra), és
mindegyikkel külön-külön (egyidőben) gyufaszálas játékot játszik (a játék leírását lásd lennebb).
A főszál generálja, hogy melyik partnerrel való játék esetén ki kezd, és aszerint inicializálja a szemaforokat (minden
játékosra két-két szemafor).
Írjuk ki, hogy mikor ki lép, és mennyit húz, illetve hány gyufa maradt a kettőjük 21 gyufaszálából (a kiírás egyetlen
sorban történjen).
A főszál írja mindig ki, hogy épp melyik szállal játszik, hogy követhető legyen a játék(ok) menete.
A vesztes kiírja, hogy gratulál a győztesnek (konkrétan, hogy kinek), majd, miután minden játszmának vége, a főszál
megvárja a szálak befejeződését, és maga is befejeződik
Gyufaszálas játék: Két játékos játszik, esetünkben ez a főszál és egy általa létrehozott szál. A játék lényege:
kezdetben 21 gyufaszál van az asztalon. A játékosok kisorsolják, hogy ki kezd, majd rendre hol az egyik hol a
másik kerül sorra, és választhat, hogy egy vagy két gyufaszálat vesz el. Az veszít, aki a legutolsó gyufaszálat
emeli el.
szinkronizálás szemaforok segítségével:
oldjuk meg a kölcsönös kizárást bármilyen osztott változóhoz való hozzáférés esetén
szemaforok segítségével oldjuk meg, hogy a főszál illetve az egyes szálak felváltva tudjanak gyufaszálakat
húzni (a főszál egy-egy lépést játszik le előbb az első, majd a második, aztán a harmadik szállal, utána ismét
az elsővel indulhat a következő lépés, stb.*/

#include <stdlib.h>
#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <sys/unistd.h>
#include <stdbool.h>

typedef struct argumentumok{
	int sorszam;
	int* gyufak;
	unsigned int r;
}argumentumok;

int n;

sem_t* t_sem;
sem_t* f_sem;

void* thread_elso(void* args){
	argumentumok* tmp = (argumentumok*) args;
	
	int i = tmp->sorszam;
	while(true){
		sem_wait(&t_sem[i]);
		sem_wait(&t_sem[i]);
	
		//ha a foszal elozo korben veszitett es nem fejezodott be ez a szal
		if(tmp->gyufak[i] <= 0){
			break;
		}

		//gyufa(k) elvevese
        int elvesz;
        if(tmp->gyufak[i] == 1){
            elvesz = 1;
        }
        else{
            elvesz = rand_r(&tmp->r)%2+1;
        }
        tmp->gyufak[i] -= elvesz;
        printf("[%d] Elvesz %d gyufat, %d maradt az asztalon\n", i, elvesz, tmp->gyufak[i]);

        //veszitett
        if(tmp->gyufak[i] <= 0){
            printf("[%d] Gratulalok a fo szalnak!\n", i);
        }

        //kovetkezo szal szemaforjanak a novelese
        if(i+1 == n){
            sem_post(&t_sem[0]);
        }
        else{
            sem_post(&t_sem[i+1]);
        }

		//fo szemafor kore
        sem_post(&f_sem[i]);

        //jatek vege
        if(tmp->gyufak[i] <= 0){
            break;
        }
	}
	printf("[%d] Befejezve\n", i);	
	return NULL;
}

void* thread_masodik(void* args){
    argumentumok* tmp = (argumentumok*) args;

    int i = tmp->sorszam;
    while(true){
		sem_wait(&t_sem[i]);
		sem_wait(&t_sem[i]);

		//foszal veszitett
        if(tmp->gyufak[i] <= 0){
			if(i+1 == n){
            	sem_post(&t_sem[0]);
        	}
        	else{
            	sem_post(&t_sem[i+1]);
        	}
			sem_post(&f_sem[i]);
            break;
        }

		//gyufa(k) elvevese
		int elvesz;
		if(tmp->gyufak[i] == 1){
			elvesz = 1;
		}
		else{
			elvesz = rand_r(&tmp->r)%2+1;
		}
		tmp->gyufak[i] -= elvesz;
		printf("[%d] Elvesz %d gyufat, %d maradt az asztalon\n", i, elvesz, tmp->gyufak[i]);
		
		//veszitett
		if(tmp->gyufak[i] <= 0){
			printf("[%d] Gratulalok a fo szalnak!\n", i);
		}

		//kovetkezo szal szemaforjanak a novelese
		if(i+1 == n){
			sem_post(&t_sem[0]);
		}
		else{
			sem_post(&t_sem[i+1]);
		}
		sem_post(&f_sem[i]);

		//jatek vege
		if(tmp->gyufak[i] <= 0){
			break;
		}
    }
    printf("[%d] Befejezve\n", i);  

    return NULL;
}


int main(){
	printf("Add meg a jatekosok szamat: ");
	scanf("%d", &n);

	//foszal veletlenszam generatora	
	srand(getpid());

	//memoria foglalas
	int* gyufak = (int*)malloc(n*sizeof(int));
	argumentumok* tmp = (argumentumok*)malloc(n*sizeof(argumentumok));
	pthread_t* th = (pthread_t*)malloc(n*sizeof(pthread_t));
	t_sem = (sem_t*)malloc(n*sizeof(sem_t));
	f_sem = (sem_t*)malloc(n*sizeof(sem_t));
	bool* kezd = (bool*)malloc(n*sizeof(bool));

	for(int i=0;i<n;i++){
		int kezdo = rand()%2;
		if(kezdo == 0){
			kezd[i] = true;
		}
		else{
			kezd[i] = false;
		}
		gyufak[i] = 21;
	}

	//semaforok inicializalasa
	for(int i=0;i<n;i++){
		if(sem_init(&t_sem[i], 0, 0) != 0){
			perror("Semafor init hiba"); 
			return 1;
		}
		if(sem_init(&f_sem[i], 0, 0) != 0){
			perror("Semafor init hiba"); 
			return 1;
		}
	}
	sem_post(&t_sem[0]);

	//threadek inditasa
	for (int i=0;i<n;i++){
		tmp[i].sorszam = i;
		tmp[i].gyufak = gyufak;
		tmp[i].r = rand();
		if(kezd[i]){
			if(pthread_create(&th[i], NULL, thread_masodik, (void*) &tmp[i]) != 0){
				perror("Thread create hiba!");
				return 1;	
			}
		}
		else{
			if(pthread_create(&th[i], NULL, thread_elso, (void*) &tmp[i]) != 0){
                perror("Thread create hiba!");
                return 1;
            }
		}
	}

	//jatek
	int i=-1;
	int lejatszott=0;
	while(true){
		i++;
		if(i==n){
			i=0;
			lejatszott=0;
		}
		if(gyufak[i] <= 0){
			//kello szmaforok novelese, mivel vege lett az i. jateknak es a szalak befejezodtek
			sem_post(&t_sem[i]);
			if(i+1==n){
				sem_post(&t_sem[0]);
			}
			else{
				sem_post(&t_sem[i+1]);
			}

			//vege az osszes jateknak
			lejatszott++;
			if(lejatszott == n){
				break;
			}
			continue;
		}
		printf("[Fo] %d. sorszamu szallal jatszunk!\n", i);

		if(kezd[i]){ //a foszal kezd
			//gyufa(k) elvevese
			int elvesz;
			if(gyufak[i]==1){
				elvesz = 1;
			}
			else{
				elvesz = rand()%2+1;
			}
			gyufak[i] -= elvesz;
        	printf("[Fo] Elvesz %d gyufat, %d maradt az asztalon.\n", elvesz, gyufak[i]);

        	//veszitett
        	if(gyufak[i] <= 0){
            	printf("[Fo] Gratulalok a(z) %d. szalnak!\n", i);
        	}
			//thread kore
			sem_post(&t_sem[i]);
			sem_wait(&f_sem[i]);
		}
		else{ //a thread kezd
			sem_post(&t_sem[i]);

			//megvarja, amig a thread lep
			sem_wait(&f_sem[i]);
			
			//thread veszitett
			if(gyufak[i] <= 0){
            	continue;
        	}

        	//gyufa(k) elvevese
        	int elvesz;
	        if(gyufak[i] == 1){
    	        elvesz = 1;
        	}
	        else{
    	        elvesz = rand()%2+1;
        	}
	        gyufak[i] -= elvesz;
    	    printf("[Fo] Elvesz %d gyufat, %d maradt az asztalon\n", elvesz, gyufak[i]);

        	//veszitett
	        if(gyufak[i] <= 0){
    	        printf("[Fo] Gratulalok a(z) %d. szalnak!\n", i);
        	}
		}
	}

	//threadek bevarasa
	for (int i=0;i<n;i++){
		if(pthread_join(th[i], NULL) != 0){
			perror("Thread join hiba");
			return 1;
		}
	}

	//memoria felszabaditas
	free(kezd);
	free(t_sem);
	free(f_sem);
	free(tmp);
	free(th);
	free(gyufak);
	return 0;
}
