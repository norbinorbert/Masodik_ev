//Boda Norbert, PP7_10, bnim2219

/*Írjunk MPI programot, melyben az osztályfőnök (0 sorszámú folyamat) ismételten értesítést küld a szülőknek a
következő iskolai előadás időpontjáról (az aktuális hét egy napja), illetve időpontjáról (hh:mm formátumban
megadott szöveges információ).

az első előadás előtt mindenkit sorra értesít: előbb a napot küldi, majd a kezdőidőpontot

a következő előadásra szóló meghíváskor szintén külön-külön értesít mindenkit, de a két információt (nap,
időpont) egyszerre közli.

a következő előadásra való meghívás már úgy történik, hogy megegyeznek, hogy az oszi csak két szülőt
értesít, azok másik 2x2=4 szülőt, akik további 2x4=8 szülőt értesítnek, stb. Az információt ezúttal, és a
továbbiakban is egyetlen üzenetben adják tovább.

megj.: A program csak akkor végzi el ezt a feladatot, ha a folyamatok száma n=2^p-1 alakú, ahol p>=2,
különben kihagyja ezt a változatot.

a következő előadásra való meghívás már úgy történik, hogy egyszerre küldi az üzenetet, üzenetszórással
(broadcast).

Mérjük le minden esetben külön külön az értesítéshez szükséges időt!

Megj.: Ha a DEBUG flag be van állítva (lásd ifdef), írjunk ki üzeneteket, amelyek lehetővé teszik a program
működésének követését, különben csak az eltelt időt írjuk ki*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <mpi.h>
#include <string.h>
#include <time.h>

typedef struct uzenet{
	char nap[20];
	char idopont[10];
}uzenet;

int main(){
	//valtozok es veletlenszam generator inicializalasa
	srand(getpid());
	unsigned int seed = rand();
	char napok[7][15] = {"Hetfo", "Kedd", "Szerda", "Csutortok", "Pentek", "Szombat", "Vasarnap"};
	char nap[20];
	char idopont[10];

	int rang;
	int folyamatok_szama;

	double start, stop;
	long unsigned int ns;

	//folyamatok inditasa
	MPI_Init(NULL, NULL);

	MPI_Comm_size(MPI_COMM_WORLD, &folyamatok_szama);
	MPI_Comm_rank(MPI_COMM_WORLD, &rang);

    //MPI struct letrehozasa
	const int nitems=2;
    int blocklengths[2] = {20,10};
    MPI_Datatype types[2] = {MPI_CHAR, MPI_CHAR};
    MPI_Datatype mpi_uzenet;
    MPI_Aint     offsets[2];

    offsets[0] = offsetof(uzenet, nap);
    offsets[1] = offsetof(uzenet, idopont);

    MPI_Type_create_struct(nitems, blocklengths, offsets, types, &mpi_uzenet);
    MPI_Type_commit(&mpi_uzenet);

	uzenet* tmp = (uzenet*)malloc(sizeof(uzenet));
	MPI_Barrier(MPI_COMM_WORLD);
	if(rang == 0){
#   	ifdef DEBUG
    	printf("Elso eset: ket uzenet kuldese\n");
		fflush(NULL);
#   	endif
	}

	if(rang == 0){ //osztalyfonok
		int nap_szam = rand_r(&seed) % 7;
		strcpy(nap, napok[nap_szam]);
		int ora	= rand_r(&seed) % 24;
		int perc = rand_r(&seed) % 60;
		if(perc < 10){
			sprintf(idopont, "%d:0%d", ora, perc);
		}
		else{
			sprintf(idopont, "%d:%d", ora, perc);
		}
		start = MPI_Wtime();
		for(int i=1;i<folyamatok_szama;i++){
#			ifdef DEBUG
			printf("[%d] Elso uzenet kuldese %d-nek\n", rang, i);
			fflush(NULL);
#			endif
			MPI_Send(nap, sizeof(nap), MPI_CHAR, i, 0, MPI_COMM_WORLD);
			
#			ifdef DEBUG
            printf("[%d] Masodik uzenet kuldese %d-nek\n", rang, i);
            fflush(NULL);
#			endif
			MPI_Send(idopont, sizeof(idopont), MPI_CHAR, i, 0, MPI_COMM_WORLD);
		}
	}
	else{ //szulok
		MPI_Recv(nap, sizeof(nap), MPI_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		#ifdef DEBUG
        printf("[%d] Elso uzenet elolvasva: %s\n", rang, nap);
		fflush(NULL);
        #endif

		MPI_Recv(idopont, sizeof(idopont), MPI_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		#ifdef DEBUG
		printf("[%d] Masodik uzenet elolvasva: %s\n", rang, idopont);
		fflush(NULL);
		#endif
	}

	//sleep(1);
	MPI_Barrier(MPI_COMM_WORLD);
	if(rang == 0){
		stop = MPI_Wtime();
		ns=(stop - start) * 1000000000;
		printf("\nElso eset futasi ideje: %lu ns (%lf s)\n", ns, ns*1.0/1000000000);
		fflush(NULL);
	}

//Masodik eset//////////////////////////////////////////////////////////////////////
	
	MPI_Barrier(MPI_COMM_WORLD);
	if(rang == 0){
#		ifdef DEBUG
		printf("\nMasodik eset: egy uzenet kuldese\n");
		fflush(NULL);
#		endif
	}

	if(rang == 0){ //osztalyfonok
        int nap_szam = rand_r(&seed) % 7;
        strcpy(nap, napok[nap_szam]);
        int ora = rand_r(&seed) % 24;
        int perc = rand_r(&seed) % 60;
		if(perc < 10){
            sprintf(idopont, "%d:0%d", ora, perc);
        }
        else{
            sprintf(idopont, "%d:%d", ora, perc);
        }

		strcpy(tmp->nap,nap);
		strcpy(tmp->idopont, idopont);

		start = MPI_Wtime();
        for(int i=1;i<folyamatok_szama;i++){
#           ifdef DEBUG
            printf("[%d] Uzenet kuldese %d-nek\n", rang, i);
            fflush(NULL);
#           endif
            MPI_Send(tmp, 1, mpi_uzenet, i, 0, MPI_COMM_WORLD);
        }
    }
    else{ //szulok
        MPI_Recv(tmp, 1, mpi_uzenet, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        #ifdef DEBUG
        printf("[%d] Uzenet elolvasva: %s %s\n", rang, tmp->nap, tmp->idopont);
        fflush(NULL);
        #endif
    }

	//sleep(1);
	MPI_Barrier(MPI_COMM_WORLD);
	if(rang == 0){
    	stop = MPI_Wtime();
		ns=(stop - start) * 1000000000;
    	printf("\nMasodik eset futasi ideje: %lu ns (%lf s)\n", ns, ns*1.0/1000000000);
		fflush(NULL);
	}
	MPI_Barrier(MPI_COMM_WORLD);

//Harmadik eset////////////////////////////////////////////////////////////
	int tmp_szam = folyamatok_szama;
	while(tmp_szam % 2 == 0){
		tmp_szam /= 2;
	}

	if(tmp_szam == 1){
		MPI_Barrier(MPI_COMM_WORLD);
    	if(rang == 0){
#       	ifdef DEBUG
        	printf("\nHarmadik eset: 2^p folyamat\n");
			fflush(NULL);
#       	endif
    		start = MPI_Wtime();
		}

    	if(rang == 0){
        	int nap_szam = rand_r(&seed) % 7;
        	strcpy(nap, napok[nap_szam]);
        	int ora = rand_r(&seed) % 24;
        	int perc = rand_r(&seed) % 60;
			if(perc < 10){
            	sprintf(idopont, "%d:0%d", ora, perc);
        	}
        	else{
            	sprintf(idopont, "%d:%d", ora, perc);
        	}

        	strcpy(tmp->nap,nap);
        	strcpy(tmp->idopont, idopont);
    	}


		if(rang != 0){
			int eltolas = 0;
			while (1){
				int tmp_rang = rang - eltolas;
				while(tmp_rang % 2 == 0){
					tmp_rang /= 2;
				}
				if(tmp_rang == 1){
					break;
				}
				eltolas++;
			}
			MPI_Recv(tmp, 1, mpi_uzenet, eltolas, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
#			ifdef DEBUG
			printf("[%d] Uzenet elolvasva %d-tol: %s %s\n", rang, eltolas, tmp->nap, tmp->idopont);
			fflush(NULL);
#			endif
		}
		if(rang == 0){
        	start = MPI_Wtime();
    	}

		if(rang <= folyamatok_szama / 2){
			int dest = 1;
			while(dest <= rang){
				dest = dest * 2;
			}
			while(dest < folyamatok_szama){
				int tmp_dest = dest + rang;
#           	ifdef DEBUG
            	printf("[%d] Uzenet kuldese %d-nek\n", rang, tmp_dest);
            	fflush(NULL);
#           	endif

				MPI_Send(tmp, 1, mpi_uzenet, tmp_dest, 0, MPI_COMM_WORLD);
				dest = dest * 2;
			}
		}

		//sleep(1);
		MPI_Barrier(MPI_COMM_WORLD);
    	if(rang == 0){
        	stop = MPI_Wtime();
			ns=(stop - start) * 1000000000;
        	printf("\nHarmadik eset futasi ideje: %lu ns (%lf s)\n", ns, ns*1.0/1000000000);
        	fflush(NULL);
    	}
	}

//Negyedik eset/////////////////////////////////////////////////////////////

	MPI_Barrier(MPI_COMM_WORLD);
	if(rang == 0){
#   	ifdef DEBUG
    	printf("\nNegyedik eset: broadcast\n");
		fflush(NULL);
#   	endif
	}

	if(rang == 0){
		int nap_szam = rand_r(&seed) % 7;
        strcpy(nap, napok[nap_szam]);
        int ora = rand_r(&seed) % 24;
        int perc = rand_r(&seed) % 60;
		if(perc < 10){
            sprintf(idopont, "%d:0%d", ora, perc);
        }
        else{
            sprintf(idopont, "%d:%d", ora, perc);
        }

        strcpy(tmp->nap,nap);
        strcpy(tmp->idopont, idopont);

#		ifdef DEBUG
       	printf("[%d] Uzenet kuldese mindenkinek\n", rang);
       	fflush(NULL);
#   	endif
	}

	MPI_Barrier(MPI_COMM_WORLD);
	if(rang == 0){
		start = MPI_Wtime();
	}
	MPI_Bcast(tmp, 1, mpi_uzenet, 0, MPI_COMM_WORLD);
	MPI_Barrier(MPI_COMM_WORLD);
	if(rang == 0){
		stop = MPI_Wtime();
	}
#	ifdef DEBUG
	if(rang != 0){
        printf("[%d] Broadcast elolvasva: %s %s\n", rang, tmp->nap, tmp->idopont);
        fflush(NULL);
	}
#	endif
	
	//sleep(1);
	MPI_Barrier(MPI_COMM_WORLD);
    if(rang == 0){
		ns=(stop - start) * 1000000000;
        printf("\nNegyedik eset futasi ideje: %lu ns (%lf s)\n", ns, ns*1.0/1000000000);
		fflush(NULL);
    }
	MPI_Barrier(MPI_COMM_WORLD);

	MPI_Type_free(&mpi_uzenet);

	MPI_Finalize();
	return 0;
}

