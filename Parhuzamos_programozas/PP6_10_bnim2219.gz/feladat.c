//Boda Norbert, PP6_10, bnim2219

/*Írjunk OpenMP API-t használó C programot, mely az alábbi feladatot oldja meg: tekintsünk egy m x n-es, 0
értékekkel inicializált mátrixot, ahol a mátrix sorai (1<= m <= 10) egy-egy tanárnak felelnek meg, az oszlopok pedig
(n>=100) egy-egy diáknak (a teszteléshez elfogadható kisebb érték is). Az m és n értékét paraméterként adjuk meg
úgy, hogy m|n. Használjunk továbbá egy m elemű segédtömböt, melyben minden egyes tanárhoz tartozik egyetlen
1 és 5 közötti érték, ami az illető tanár által oktatott tárgy(ak) népszerűségét jelöli (nagyobb érték nagyobb
népszerűséget jelent).

Kezdetben minden diák választ egy vezetőtanárt az államvizsga-dolgozathoz, azaz a mátrix minden egyes
oszlopába kerüljön egy és csakis egy 1-es érték (a tanár sorszámának megfelelő véletlenszám generálását úgy
oldjuk meg, hogy a népszerűbb tárgyakat oktató tanárokat a népszerűségi mutatónak megfelelő arányban többen
válasszák). Az 1-esek generálását oldjuk meg kétféleképpen (ugyanazon a programon belül): szekvenciálisan, illetve
OpenMP-vel párhuzamosítva, és mérjük le a kérdéses kódrészek szekvenciális illetve párhuzamos futási idejét, majd
számítsuk ki az elért gyorsítást.

Az intézet szabályzata előírja, hogy egy tanár max. n/m diák vezetését vállalhatja el.
Indítsunk a tanárok számának megfelelő szálat, melyben minden tanár megszámolja, hogy hány diák
iratkozott hozzá, ezt a kiszámolt a értéket beleírja egy segédtömbbe. Az, akinek kevesebb diákja van,
megjelöli az eredetileg hozzá iratkozott diákokat (pl. átírja az 1-est, hozzáadva 10-et). Miután minden tanár
befejezte a számolást és a megjelölést, azok a tanárok, akiknek a megengedettnél több diákjuk van,
megpróbálják elérni, hogy csak az előírt n/m számú diákjuk maradjon:

A tanár egyesével csökkenti a diákjainak számát, amíg az el nem éri az n/m-t: azaz ismételten generál egy 1
és a közötti értéket, és a megfelelő diáknak (vagyis a tanárnak megfelelő sorban az annyiadik 1-esről van szó)
keres egy tanárt, akinek nincs elég diákja (addig generál egy véletlenszerű értéket, amíg nem talál egy
megfelelőt), átírja a diákot a megfelelő pozícióba, de nem 1-est ír be, hanem az ő sorszámát, hogy a kolléga
tudja, hogy kitől került át az illető diák. Ő maga lemondja az illető diákot, vagyis a megfelelő pozícióban
lenulláza az 1-est, és csökkenti a diákjainak számát (vagyis az a értékét), majd ugyanezt ismétli, amíg
szükséges.

az összes tanár megvárja, míg mindenki befejezte a módosításokat, majd egy kritikus szakaszban kiírják az
következőket:
hány diákjuk volt eredetileg,ebből hányat adtak át és kiknek VAGY
kitől hány diákot kaptak

A követhetőség kedvéért írjuk ki a feladat elején és a végén is a mátrix értékét egy out.dat állományba.*/

#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <unistd.h>
#include <time.h>

int main(int argc, char* argv[]){
	if(argc != 3){
		printf("Helytelen parameterezes!\nHasznalat: %s m n\n", argv[0]);
		return 1;
	}
	int m = atoi(argv[1]);
	if(m < 1 || m > 10){
		printf("Megkotes nincs betartva: 0 <= m <= 10\n");
		return 1;
	}
	int n = atoi(argv[2]);
	if(n < 10){
        printf("Megkotes nincs betartva: n >= 100\n");
		return 1;
	}
	if(n % m != 0){
		printf("Megkotes nincs betartva: m|n\n");
		return 1;
	}

	FILE* out = fopen("out.dat", "w");

	//helyfoglalas es tanar nepszeruseg szamitas	
	srand(getpid());
	
	int* tanarok = (int*)calloc(m, sizeof(int));
	int ossz_nepszeruseg = 0;
	
	int** matrix = (int**)calloc(m, sizeof(int*));
	for(int i=0; i<m; i++){
		matrix[i] = (int*)calloc(n, sizeof(int));
		tanarok[i] = rand() % 5 + 1;
		ossz_nepszeruseg += tanarok[i];
	}
	
	//idomeres kezdete
	struct timespec start, stop;
	clock_gettime(CLOCK_REALTIME, &start);

	//szekvencialis random generalas
	unsigned int seed = rand();
	for(int i=0;i<n;i++){
		int valasztas = rand_r(&seed) % ossz_nepszeruseg + 1;
		int j = -1;
		while(valasztas > 0){
			j++;
			valasztas -= tanarok[j];
		}
		matrix[j][i] = 1;
	}
	//idomeres vege
	clock_gettime(CLOCK_REALTIME, &stop);
	long unsigned int ns=(stop.tv_sec - start.tv_sec) * 1000000000 + stop.tv_nsec - start.tv_nsec;
	printf("\nSzekvencialis ido: %lu ns (%lf s)\n", ns, ns*1.0/1000000000);
	
	//memoria felszabaditas, hogy minden legyen lenullazva
	for(int i=0;i<m;i++){
		free(matrix[i]);
	}
	free(matrix);
	
	matrix = (int**)calloc(m, sizeof(int*));
	for(int i=0; i<m; i++){
        matrix[i] = (int*)calloc(n, sizeof(int));
    }

	//idomeres kezdete
	clock_gettime(CLOCK_REALTIME, &start);

    //parhuzamos random generalas
#	pragma omp parallel default(none) \
	shared(matrix, tanarok, n, ossz_nepszeruseg) private(seed)
{
	seed = omp_get_thread_num();
#	pragma omp for
    for(int i=0;i<n;i++){
        int valasztas = rand_r(&seed) % ossz_nepszeruseg + 1;
        int j = -1;
        while(valasztas > 0){
            j++;
            valasztas -= tanarok[j];
        }
        matrix[j][i] = 1;
    }
}   
    //idomeres vege
    clock_gettime(CLOCK_REALTIME, &stop);
    long unsigned int ns_p=(stop.tv_sec - start.tv_sec) * 1000000000 + stop.tv_nsec - start.tv_nsec;
    printf("Parhuzamos ido: %lu ns (%lf s)\n", ns_p, ns_p*1.0/1000000000);

	if((int)(ns)-(int)(ns_p) > 0){
		printf("\nElert gyorsitas: %lf  \n", (double)(ns) / ns_p);
	}
	else{
		printf("\nNem ertunk el gyorsitast a parhuzamos verzioval\n");
	}

	//matrix kiirasa fileba
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			fprintf(out, "%d ", matrix[i][j]);
		}
		fprintf(out, "\n");
	}
	fprintf(out, "\n");
	
	int* seged = (int*)calloc(m, sizeof(int));
	int* seged2 = (int*)calloc(m, sizeof(int));
#	pragma omp parallel num_threads(m) default(none) \
	shared(matrix, seged, seged2, m, n) private(seed)
{
	//tanarok megszamoljak, hogy hany diakjuk van
	seed = omp_get_thread_num();
	int a = 0;
#	pragma omp for
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			if(matrix[i][j] == 1){
				a++;
			}
		}
		if(a <= n/m){
			for(int j=0;j<n;j++){
				if(matrix[i][j] == 1){
					matrix[i][j] = 11;
				}
			}
		}
		seged[i] = a;
		seged2[i] = a;
	}
	int* kiir_seged = (int*)calloc(m+1, sizeof(int));
#	pragma omp for
	//diakok atadasa
	for(int i=0;i<m;i++){
		while(a > n/m){
			int diak = rand_r(&seed) % a + 1;
			int j = -1;
			int sorszam = 0;
			while(sorszam != diak){
				j++;
				if(matrix[i][j] != 0){
					sorszam++;
				}
			}
			matrix[i][j] = 0;
#		pragma omp critical
		{	
			int tanar;
			do{
				tanar = rand_r(&seed) % m;
			}while(seged2[tanar] >= n/m);

			int index = 0;
			while(matrix[tanar][index] != 0){
				index++;
			}
			matrix[tanar][index] = i+1;
			seged2[tanar]++;
			kiir_seged[tanar+1]++;
		}
			a--;
		}

	}

#	pragma omp for	
	//kiiras
	for(int i=0;i<m;i++){
#	pragma omp critical
		{
			printf("[%d] Eredeti diakok szama: %d ", i+1, seged[i]);
			if(seged[i] < n/m){
				printf("Kapott diakok szama: %d\n", n/m - seged[i]);
				for(int j=0;j<n;j++){
					if(matrix[i][j] > 0 && matrix[i][j] < 11){
						kiir_seged[matrix[i][j]]++;
					}
				}
				for(int j=0;j<=m;j++){
					if(kiir_seged[j] > 0){
						printf("%d-tol kaptam %d diakot\n", j, kiir_seged[j]);
					}
				}
			}
			if(seged[i] > n/m){
				printf("Atadott diakok szama: %d\n", seged[i] - n/m);
				for(int j=0;j<=m;j++){
                    if(kiir_seged[j] > 0){
                        printf("%d-nek adtam %d diakot\n", j, kiir_seged[j]);
                    }
                }
			}
			printf("\n");
			free(kiir_seged);
		}
	}
}
	//kiiras fileba
	for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            fprintf(out, "%d ", matrix[i][j]);
        }
        fprintf(out, "\n");
    }

	//memoria felszabaditas
	for(int i=0;i<m;i++){
        free(matrix[i]);
    }
    free(matrix);
	free(tanarok);
	free(seged);
	free(seged2);
	fclose(out);
	return 0;
}
